<?php

define("PATH_DAO", dirname(__FILE__) . '/DAO/');
define("PATH_VIEW", dirname(__FILE__) . '/Views/');
define("PATH_CONTROLLER", dirname(__FILE__) . '/Controller/');