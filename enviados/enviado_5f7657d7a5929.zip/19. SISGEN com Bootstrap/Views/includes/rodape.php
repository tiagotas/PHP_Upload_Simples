
<footer class="container mt-5">

    <div class="text-center">
        <p>
            SISGEN - Sistema de Gestão - Todos os direitos reservados.
        </p>
        <p>
            Programação Web com @prof.tiagotas
        </p>
    </div>

</footer>