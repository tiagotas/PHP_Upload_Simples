<html lang="pt-br">
    <head>
        <title>LOGIN</title>
        <meta charset="utf8" />
    </head>
    <body>
        <div id="global">
            <header>
                <h1>Login</h1>
            </header>
            <main>
                <form method="post" action="autenticador.php">
                    
                    <label>Usuário:
                        <input name="user" type="text" />
                    </label>

                    <label>Senha:
                        <input name="pass" type="password" />
                    </label>
                    <button type="submit">Entrar</button>
                </form>
            </main>
            <footer>
            </footer>
        </div>
    </body>
</html>